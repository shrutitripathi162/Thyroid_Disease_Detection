# Thyroid_Disease_Project

Code of Thyroid Disease Detection Project, which we can use to detect the thyroid disease of an individual. 
